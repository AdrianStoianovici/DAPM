Buna, 

Acesta este link-ul de unde am luat tutorialul pentru aplicatia SQLite : https://abhiandroid.com/database/sqlite

si acesta este link-ul cu contul de github unde am postat laboratorul : https://github.com/AdrianStoianovici/DAPM

O zi frumoasa,

Gomoescu Raluca
Stoianovici Adrian